<?php $__env->startSection('content'); ?>
<?php if(Auth::user()->ocupation == "GERENTE"): ?>
<!-- <div class="container"> -->
    <div class="row justify-content-center">
        <!--
        <div class="col-md-4">
            <div class="card">
            	<a href="<?php echo e(route('almacen.index')); ?>">
	                <div class="card-header">
	                	ALMACÉN
	                </div>
	                <div class="card-body">
	                    <img src="<?php echo e(asset('imagenes/Almacen.jpg')); ?>" width="100%" style="height: 218px;">
	                </div>
            	</a>
            </div>
        </div>
        -->

        <div class="col-md-4">
            <div class="card">
            	<a href="<?php echo e(route('clientes.index')); ?>">
	                <div class="card-header">
	                	CLIENTES
	                </div>
	                <div class="card-body">
	                    <img src="<?php echo e(asset('imagenes/clientes.jpg')); ?>" width="100%" style="height: 218px;">
	                </div>
            	</a>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card">
            	<a href="<?php echo e(route('ordenes.index')); ?>">
                	<div class="card-header">
                		ORDENES
            		</div>
                	<div class="card-body">
                    	<img src="<?php echo e(asset('imagenes/tomar-orden.jpg')); ?>" width="100%" style="height: 218px;">
                	</div>
            	</a>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card">
            	<a href="<?php echo e(route('ventas.index')); ?>">
                	<div class="card-header">
                		VENTAS
            		</div>
                	<div class="card-body">
                    	<img src="<?php echo e(asset('imagenes/Ventas.jpg')); ?>" width="100%" style="height: 218px;">
                	</div>
            	</a>
            </div>
        </div>
        <!--
        <div class="col-md-4">
            <div class="card">
            	<a href="">
	                <div class="card-header">
	                	COMPRAS
	            	</div>
	                <div class="card-body">
	                    <img src="<?php echo e(asset('imagenes/Compras.jpg')); ?>" width="100%" style="height: 218px;">
	                </div>
	            </a>
            </div>
        </div>
        -->
    </div>

    <hr>

    <div class="row justify-content-center">
        <!--
        <div class="col-md-4">
            <div class="card">
            	<a href="<?php echo e(route('proveedor.index')); ?>">
	                <div class="card-header">
	                	PROVEEDORES
	                </div>
	                <div class="card-body">
	                    <img src="<?php echo e(asset('imagenes/Proveedor.jpg')); ?>" width="100%" style="height: 218px;">
	                </div>
                </a>
            </div>
        </div>
        -->

        <div class="col-md-4">
            <div class="card">
            	<a href="<?php echo e(route('producto.index')); ?>">
	                <div class="card-header">
	                	PRODUCTOS
	            	</div>
	                <div class="card-body">
	                    <img src="<?php echo e(asset('imagenes/Productos.jpg')); ?>" width="100%" style="height: 218px;">
	                </div>
                </a>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card">
            	<a href="<?php echo e(route('administracion.index')); ?>">
	                <div class="card-header">
	                	ADMINISTRACIÓN
	            	</div>
	                <div class="card-body">
	                    <img src="<?php echo e(asset('imagenes/Administracion.jpg')); ?>" width="100%" style="height: 218px;">
	                </div>
                </a>
            </div>
        </div>

    </div>
<!-- </div> -->
<?php elseif(Auth::user()->ocupation == "MESERO"): ?>
<!-- <div class="container"> -->
    <div class="row justify-content-center">
    	
        <div class="col-md-4">
            <div class="card">
            	<a href="<?php echo e(route('ordenes.index')); ?>">
                	<div class="card-header">
                		ORDENES
            		</div>
                	<div class="card-body">
                    	<img src="<?php echo e(asset('imagenes/tomar-orden.jpg')); ?>" width="100%" style="height: 218px;">
                	</div>
            	</a>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card">
                <a href="<?php echo e(route('ventas.index')); ?>">
                    <div class="card-header">
                        VENTAS
                    </div>
                    <div class="card-body">
                        <img src="<?php echo e(asset('imagenes/Ventas.jpg')); ?>" width="100%" style="height: 218px;">
                    </div>
                </a>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                	OPCIÓN 3
            	</div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

    </div>

    <hr>

    <div class="row justify-content-center">

        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                	OPCIÓN 4
                </div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                	OPCIÓN 5
            	</div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                	OPCÍÓN 6
            	</div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

    </div>
<!-- </div> -->
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>