<?php $__env->startSection('content'); ?>

<?php if(Auth::user()->ocupation == "ADMINISTRADOR"): ?>
<div class="container">
    <div class="row justify-content-center">
    	<table id="tableAlmacen">
        	<thead class="thead-dark">
                <tr>
                    <th data-field="" data-sortable="true"></th>
                    <th data-field="" data-sortable="true"></th>
                    <th data-field="" data-sortable="true"></th>
                    <th data-field="" data-sortable="true"></th>
                    <th data-field="" data-sortable="true"></th>
                    <th data-field="" data-sortable="true"></th>
                    <th data-field="" data-sortable="true"></th>
                </tr>
            </thead>
        </table>
	</div>
</div>
<?php elseif(Auth::user()->ocupation == "CAJERO"): ?>

<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
	$(document).ready(function () {
		
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>