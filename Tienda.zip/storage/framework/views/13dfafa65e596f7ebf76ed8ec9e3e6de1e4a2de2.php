<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
        <?php echo e($errors->first('compania')); ?>

            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<div class="container">
    <div class="card">
        <div class="card-header">
            <h5>Capturar Orden de Pago</h5>
        </div>
        <div class="card-body">
            <?php echo Form::open(['id'=>'formNewOrden','novalidate','class'=>'needs-validation','route' => 'pruebas.store', 'method'=>'POST']); ?>

                <div class="row pb-3">
                    <div class="col-9">
                        <?php echo e(Form::label('compania', 'COMPAÑÍA:')); ?>

                        <?php echo e(Form::text('compania',null,array('required','class'=>'form-control mayuscula'. ( $errors->has('compania') ? ' is-invalid' : '' ),'title'=>'Área que tramita'))); ?>

                        <?php if($errors->any()): ?><div id="error_compania" class="invalid-feedback"><?php echo e($errors->first('compania')); ?></div><?php endif; ?>
                        
                        <?php if($errors->any()): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('compania')); ?></strong>
                                    </span>
                                <?php endif; ?>
                    </div>
                    <div class="col-3">
                        <?php echo e(Form::label('direccion', 'DIRECCIÓN:')); ?>

                        <?php echo e(Form::text('direccion',null,array('required','class'=>'form-control mayuscula','title'=>''))); ?>

                        <div id="error_direccion"></div>
                        <?php if($errors->has('direccion')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('direccion')); ?></strong>
                                    </span>
                                <?php endif; ?>
                    </div>
                </div>
                <div class="row pb-3">
                    <div class="col-3">
                        <?php echo e(Form::label('telefono', 'TELÉFONO:')); ?>

                        <?php echo e(Form::text('telefono',null,array('required','class'=>'form-control mayuscula','title'=>'Número de trámite'))); ?>

                        <div id="error_telefono"></div>
                    </div>
                    <div class="col-3">
                        <?php echo e(Form::label('correo', 'CORREO:')); ?>

                        <?php echo e(Form::text('correo',null,array('required','class'=>'form-control','title'=>'Fecha de elaboración'))); ?>

                        <div id="error_correo"></div>
                    </div>
                    <div class="col-3">
                        <?php echo e(Form::label('estatus', 'O.C. :')); ?>

                        <?php echo e(Form::select('estatus',$estatus,null,array('required','class'=>'form-control','title'=>'Tipo de trámite'))); ?>

                        <div id="error_estatus"></div>
                    </div>
                </div>
                <hr class="my-4">
                <div id="footer-buttons col-md-12">
                    <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary btn-lg','id'=>'guardarOrden']); ?> 
                </div>
            <?php echo Form::close(); ?>

        </div>
    </div>  
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">

/*(function() {
  'use strict';
  window.addEventListener('load', function() {
    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.getElementsByClassName('needs-validation');
    // Loop over them and prevent submission
    var validation = Array.prototype.filter.call(forms, function(form) {
      form.addEventListener('submit', function(event) {
        if (form.checkValidity() === false) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);
    });
  }, false);
})();*/

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>